/**@autor AonoZan Dejan Petrovic 2016 �
 */
package _XX01_DodatniDan;

import java.util.ArrayList;

public class Biblioteka {
	private ArrayList<Racun> listaRacuna;
	private ArrayList<Knjiga> listaKnjiga;
	private ArrayList<Posudjivanje> listaPosudjivanja;
	
	Biblioteka(){
		listaRacuna = new ArrayList<Racun>();
		listaKnjiga = new ArrayList<Knjiga>();
		listaPosudjivanja = new ArrayList<Posudjivanje>();
	}
	
	public void dodajKnjigu(int brojKnjige, String imeKnjige){
		if (brojKnjige > 0 && !daLiKnjigaPostoji(brojKnjige)) {
			Knjiga novaKnjiga = new Knjiga(brojKnjige, imeKnjige);
			listaKnjiga.add(novaKnjiga);
		}else {
			System.out.println("Broj nije validan.");
		}
	}
	public void dodajRacun(int brojRacuna, String imeRacuna){
		if (brojRacuna > 0 && !daLiRacunPostoji(brojRacuna))
	}
	
	private boolean daLiKnjigaPostoji(int brojKnjige){
		if (!listaKnjiga.isEmpty()) {
			for (Knjiga knjiga : listaKnjiga) {
				if(knjiga.getBrojKnjige() == brojKnjige) return true;
			}
		}
		return false;
	}
	private boolean daLiRacunPostoji(int brojRacuna){
		if (!listaRacuna.isEmpty()) {
			for (Racun racun : listaRacuna) {
				if(racun.getBrojRacun() == brojRacun) return true;
			}
		}
		return false;
	}
}
